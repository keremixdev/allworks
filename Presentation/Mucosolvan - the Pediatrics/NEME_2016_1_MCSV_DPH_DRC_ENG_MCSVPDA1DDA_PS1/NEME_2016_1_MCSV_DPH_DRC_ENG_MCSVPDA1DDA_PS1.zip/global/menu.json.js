var menudata = [
	{
		"id": 1,
		"path": "0.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVPDA1DDA_Home"
	},
	{
		"id": 2,
		"path": "1.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVPDA1DDA_HPA"
	},
	{
		"id": 3,
		"path": "2.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVPDA1DDA_Sa_Pr"
	},
	{
		"id": 4,
		"path": "3.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVPDA1DDA_PS1"
	},
	{
		"id": 5,
		"path": "4.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVPDA1DDA_ProEOA3"
	},
	{
		"id": 6,
		"path": "5.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVPDA1DDA_Sum"
	},
	{
		"id": 7,
		"path": "6.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVPDA1DDA_Ref"
	},
	{
		"id": 30,
		"path": "23.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVPDA1DDA_Sitemap",
		"hideonmenu": true,
		"hideonslide": true
	}
];