var menudata = [
	{
		"id": 1,
		"path": "0.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVP1DDA_Home"
	},
	{
		"id": 2,
		"path": "1.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVP1DDA_HPR"
	},
	{
		"id": 3,
		"path": "2.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVP1DDA_Me_Needs"
	},
	{
		"id": 5,
		"path": "4.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVP1DDA_Ambroxol"
	},
	{
		"id": 6,
		"path": "5.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVP1DDA_PS1"
	},
	{
		"id": 7,
		"path": "6.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVP1DDA_PS2"
	},
	{
		"id": 8,
		"path": "7.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVP1DDA_PS3"
	},
	{
		"id": 9,
		"path": "8.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVP1DDA_Sum"
	},
	{
		"id": 10,
		"path": "9.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVP1DDA_Ref"
	},
	{
		"id": 30,
		"path": "22.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVP1DDA_Sitemap",
		"hideonmenu": true,
		"hideonslide": true
	}
];